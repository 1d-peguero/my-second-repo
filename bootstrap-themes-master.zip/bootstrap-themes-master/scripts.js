// init wow animations
new WOW().init();